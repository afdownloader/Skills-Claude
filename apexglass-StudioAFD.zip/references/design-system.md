# ApexGlass Design System

Centralize colors, spacing, typography, radius, depth and component tokens.