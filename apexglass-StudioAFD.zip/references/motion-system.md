# Motion System

Use purposeful state transitions and respect reduced-motion preferences.