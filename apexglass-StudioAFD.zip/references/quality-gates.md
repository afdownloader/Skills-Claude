# Quality Gates

Verify structure, visual consistency, UX, responsive behavior, accessibility and performance.