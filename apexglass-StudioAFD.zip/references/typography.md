# Typography

Use clear hierarchy, readable line-height, consistent weights and responsive scaling.