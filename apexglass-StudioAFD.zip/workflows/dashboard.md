# Dashboard Workflow

Prioritize data hierarchy, navigation, density, states and responsive behavior.