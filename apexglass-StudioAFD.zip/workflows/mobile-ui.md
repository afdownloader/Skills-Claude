# Mobile UI Workflow

Prioritize touch targets, navigation, hierarchy, accessibility and performance.