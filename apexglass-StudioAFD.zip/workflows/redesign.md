# Redesign Workflow

Inspect existing system → preserve functionality → improve affected areas → verify.