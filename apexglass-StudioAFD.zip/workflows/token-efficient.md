# Token-Efficient Workflow

Retrieve only relevant context, modify only affected files, avoid redundant regeneration, verify dependencies.