# Website Workflow

Define information architecture, responsive layout, visual system and implementation.